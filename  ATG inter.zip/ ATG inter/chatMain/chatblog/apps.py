from django.apps import AppConfig


class ChatblogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatblog'
