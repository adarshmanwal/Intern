from django.db import models

# Create your models here.
class Post(models.Model):
    name=models.CharField(max_length=40)
    email=models.CharField(max_length=50)
    mood=models.CharField(max_length=20)










# from django.db import models
# from django.contrib.auth.models import User
# from django.db.models.deletion import CASCADE
# from django.http import request

# # Create your models here.
# class Post(models.Model):
#     # author = models.ForeignKey(User, null=True, blank=True)[e]
#     # author=models.ForeignKey(User,max_length=30,on_delete=CASCADE)
#     # author
#     Title=models.CharField(max_length=100)
#     Content=models.CharField(max_length=1000)