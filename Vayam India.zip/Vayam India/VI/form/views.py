
from django.shortcuts import redirect, render
from .models import Post


# Create your views here.
def home(request):        
    return render(request,'form/home.html')

def inputform(request):

    status=[]
    flag=0
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        status.append(request.POST['a'])
        status.append(request.POST['b'])
        status.append(request.POST['c'])
        status.append(request.POST['d'])
        status.append(request.POST['e'])
        # print(status)
        for i in status:
            if i=='1':
                flag=flag+1
        if(flag>=3):
            mood="HAPPY"
        else:
            mood="SAD"
        print(name,email,mood)
        ins=Post(name=name,email=email,mood=mood)
        ins.save()
        redirect('form/home.html')
    else:
        print("page not found")

    return render(request,'form/form.html')